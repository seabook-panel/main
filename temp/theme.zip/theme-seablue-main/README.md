# 入海蓝 Theme-Seablue
入海蓝主题是海书面板的默认主题。
